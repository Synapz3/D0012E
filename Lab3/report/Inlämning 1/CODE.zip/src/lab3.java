
import java.util.Random;
import graph.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
/**
 * Created by Synapz3 on 2015-12-09.
 */
public class lab3 {
    private static Random rand = new Random();
   //code goes here :)
   static File file;
    public static void main(String[] args) throws FileNotFoundException, IOException {
        {


            //40000 & 40000 & 4
            //40000 & 40000 & 8
            //40000 & 80000 & 4
            //40000 & 80000 & 8
            //20000 & 160000 & 16

            //20000 & 20000 & 4 & d
            //20000 & 20000 & 8 & d
            //20000 & 40000 & 4 & d
            //20000 & 40000 & 8 & d
            //20000 & 80000 & 4 & d
            //20000 & 80000 & 8 & d

            int node = 40000;
            int d = 32;
            int edge = 40000;
            int numOfTests = 20;
            int randomMax = node;

            for (int i = 1; i <= numOfTests; i++) {

                Random rand = new Random(); //Generate two different random values.
                int rand1 = rand.nextInt(randomMax);
                int rand2 = rand.nextInt(randomMax);
                while (rand1 == rand2) {
                    rand2 = rand.nextInt(randomMax);
                }
                System.out.println("");
                System.out.println("");
                System.out.println("Building graph...");
                Graph gr = new Graph(node, d, edge);
                System.out.println("Test " + i + ": Using random integers: " + rand1 + " and " + rand2 + ".");


                long startTime = System.currentTimeMillis();
                new DijkstrArr(node, gr.nodes.get(rand1), gr.nodes.get(rand2), d); // use the random values to match nodes
                long testTime = System.currentTimeMillis() - startTime;
                System.out.println("Test time: " + testTime);

                try {

                    file = new File("Nodes "+node+", D "+d+", Edges "+edge+", Number_of_Runs "+numOfTests+".txt");
                    // if file doesnt exists, then create it
                    if (!file.exists()) {
                        file.createNewFile();
                    }

                    // Write text on  txt file.
                    FileWriter fw = new FileWriter(file, true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    bw.write(testTime+" \n");
                    bw.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

        }
    }
}

